<aside class="main-sidebar">
    <!-- sidebar -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
		 <div class="ulogo">
			 <a href="dashboard.php">
			  <!-- logo for regular state and mobile devices -->
			  <div><img src="images/logo-dark-text.png"></div>
			</a>
		</div>

        
      </div>
      
      <!-- sidebar menu -->
      <ul class="sidebar-menu" data-widget="tree">
		<li class="nav-devider"></li>
        <li>
          <a href="dashboard.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
        </li>
        <li class="treeview active">
          <a href="#">
            <i class="fa fa-th"></i>
            <span>Menus</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li  class="active"><a href="iot_reports.php">IoT Details</a></li>
            <li><a href="users_details.php">Users List</a></li>
          </ul>
        </li>
        
        

		
        		
		
        

                
        
      </ul>
    </section>
  </aside>